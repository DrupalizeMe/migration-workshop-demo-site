<?php

/**
 * @file
 * #ddev-generated: Automatically generated drushrc.php file (for Drush 8)
 * ddev manages this file and may delete or overwrite the file unless this comment is removed.
 * Remove this comment if you don't want ddev to manage this file.
 */

if (getenv('IS_DDEV_PROJECT') == 'true') {
  $options['l'] = "https://2018.tcdrupal.org.ddev.site";
}
